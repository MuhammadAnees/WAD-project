<?php
//login.php
session_start();
$connect = mysqli_connect("localhost", "root", "", "authentication");
if(isset($_POST["email"]) && isset($_POST["password"]))
{
 $email = mysqli_real_escape_string($connect, $_POST["email"]);
 $password = (mysqli_real_escape_string($connect, $_POST["password"]));
 $sql = "SELECT * FROM users WHERE email = '".$email."' AND password = '".$password."'";
 $result = mysqli_query($connect, $sql);
 $num_row = mysqli_num_rows($result);
 header("location:google.com");
 if($num_row > 0)
 {
  $data = mysqli_fetch_array($result);
  $_SESSION["username"] = $data['username'];
  header("location:home.php");
  echo $data["username"];
 }
}
?>