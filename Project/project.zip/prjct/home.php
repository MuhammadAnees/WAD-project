

<!DOCTYPE html>
<html>
<head>

<style type="text/css">
	#body{

		background-color:#111118;
	}

</style>


<style type="text/css">
	


#body{
/*background-image:linear-gradient(rgba(0,0,0,0.7),rgba(0,0,0,0.7)), url("BL12_Banking.jpg");  */
/*background-color:#111118 ; 
height:100vh;
	background-position: center;
	background-size: cover;
	background-repeat: no-repeat;
	*/
}

#login-name{
	font-size: 30px;
font-style: italic;
	color: white;
	font-weight: lighter;
}

#login{

	background-color: #0d0d0d;
	min-height: 400px;
	opacity: 0.70;
	padding: 30px 50px 30px 50px;
	box-shadow: -3px -3px 3px #33cc33;
}

.user{
font-style: italic;
	font-size: 14px;
	color: white;
	font-weight: lighter;

}

#iconn{
background-color: #5cb85c;
border-color:#4cae4c;
color: white;

}


.close {
  position: absolute;
  right: 25px;
  top: 0;
  color:white;
  font-size: 35px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color:white;
  cursor: pointer;
}

#closebar{

	color:white;
	opacity: 1;
}
</style>



<style type="text/css">
	


#body{
/*background-image:linear-gradient(rgba(0,0,0,0.7),rgba(0,0,0,0.7)), url("BL12_Banking.jpg");  */
/*background-color:#111118 ; 
height:100vh;
	background-position: center;
	background-size: cover;
	background-repeat: no-repeat;
	*/
}

#login-name{
	font-size: 30px;
font-style: italic;
	color: white;
	font-weight: lighter;
}

#signup{

	background-color: #0d0d0d;
	min-height: 400px;
	opacity: 0.70;
	padding: 30px 50px 30px 50px;
	box-shadow: -3px -3px 3px #33cc33;
}

.user{
font-style: italic;
	font-size: 14px;
	color: white;
	font-weight: lighter;

}

#iconn{
background-color: #5cb85c;
border-color:#4cae4c;
color: white;

}


.close {
  position: absolute;
  right: 25px;
  top: 0;
  color:white;
  font-size: 35px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color:white;
  cursor: pointer;
}

#closebar{

	color:white;
	opacity: 1;
}
</style>



	<title></title>



<!-- Bootstrap-->
<!--
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>

	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
 


-->



<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>




<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">


</head>
<body id="body">

<!-- navigation bar-->


<nav class="navbar navbar-expand-md navbar-dark bg-dark sticky-top">

<a href="" class="navbar-brand">
	<img src="">
	<span class="navbar-text">E-BANKING

	</span>
	

	
</a>

<button type="button" class="navbar-toggler" data-target="#navbarResponsive" data-toggle="collapse" >
	<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarResponsive">
	<ul class="navbar-nav ml-auto">
		<li class="nav-item">
			<a href="home.php" class="nav-link">Home</a>
		</li>
		<li class="nav-item">
			<a href="home.php" class="nav-link">Services</a>
		</li>
		
		<li class="nav-item">
			<a href="home.php" class="nav-link">About</a>
		</li>
		<li class="nav-item">
			<a href="home.php" class="nav-link">Help</a>
		</li>

		<li class="nav-item">
			<button class="btn btn-success nav-link rounded-circle" data-target="#login" data-toggle="modal">Login</button>
		</li>

		<li class="nav-item">
			<button class=" btn btn-success nav-link rounded-circle" data-target="#signup" data-toggle="modal">Signup </button>


		</li>
	</ul>
</div>
</nav>


<!-- image slider -->

<div class="carousel slide " data-ride="carousel" id="MagicCarousel">
	<ol class="carousel-indicators">
	<li data-target="#MagicCarousel" data-slide-to="0" class="active"></li>
	<li data-target="#MagicCarousel" data-slide-to="1"></li>
	<li  data-target="#MagicCarousel" data-slide-to="2"></li>
	</ol>

	<div class="carousel-inner" role="listbox">

		<div class="carousel-item active">
			<img src="img/banking5.jpg" class="d-block w-100">
			<div class="carousel-caption">

			<button type="button" class="btn btn-outline-light btn-lg">GetStarted</button>

			</div>
			</div>
		

	
<div class="carousel-item ">
			<img src="img/banking5.jpg" class="d-block w-100">
			<div class="carousel-caption">
			<button type="button" class="btn btn-outline-light btn-lg">GetStarted</button>
			</div>
			</div>
		


		<div class="carousel-item ">
			<img src="img/banking5.jpg" class="d-block w-100">
			<div class="carousel-caption">
			<button type="button" class="btn btn-outline-light btn-lg">GetStarted</button>
			</div>
			</div>
		

		<a href="#MagicCarousel" class="carousel-control-prev" role="button" data-slide="prev" >
			<span class="carousel-control-prev-icon"></span>
		</a>

		<a href="#MagicCarousel" class="carousel-control-next" role="button" data-slide="next">
			<span class="carousel-control-next-icon"></span>
		</a>
</div>
	</div>
</div>


<div class="text-center my-2">
	<a href="" style="text-decoration: none;"><h1 class="text-white">SERVICES</h1></a>
</div>


<!-- Three column section -->
<div class="container my-2">
	<div class="row text-center padding  ">
		<div class="col-xs-12 col-sm-6 col-md-4 bg-dark text-white border border-primary ">
			<i></i>
			<a href="#money" style="text-decoration: none"><h3>Manage Your Account</h3></a>
			<p>Check out your present Balance 
Le  matin, mon père travaille au bureau, ma mère reste à la maison, ma petite sœur va à l'école, et je vais à l'université. Le mardi, le mercredi, le jeudi, et finalement le vendredi, nous faisons la m</p>
		</div>


		<div class="col-xs-12 col-sm-6 col-md-4 bg-dark text-white border border-primary ">
			<i></i>
			<a href="#car" style="text-decoration: none"><h3>Buy a Home/Car</h3></a>
			<p>Buy a new Home at beautifull location  
Le  matin, mon père travaille au bureau, ma mère reste à la maison, ma petite sœur va à l'école, et je vais à l'université. Le mardi, le mercredi, le jeudi, et finalement le vendredi, nous faisons la m</p>
		</div>

		
		<div class="col-xs-12 col-sm-6 col-md-4 bg-dark text-white border border-primary" >
			<i></i>
			<a href="#bills" style="text-decoration: none"><h3>Pay Bills</h3></a>
			<p>Pay your Bills Electronically  
Le lundi matin, mon père travaille au bureau, ma mère reste à la maison, ma petite sœur va à l'école, et je vais à l'université. Le mardi, le mercredi, le jeudi, et finalement le vendredi, nous faisons la m</p>
		</div>


	</div>

</div>

<div id="home"  class=" my-3">
	

</div>


<div id="money"  class="bg-dark text-white border border-primary my-3">
	<h1>Manage Account</h1>
<div class="container-fluid padding">
	<div class="row padding">




		
	<div class="col-lg-6">
<form method="post" action="home.php">
	<div class="form-group col-md-4">
			<label class="user">Account ID</label><br>
			<div class="input-group">
			<input type="text" name="accountid" placeholder="e.g 122344908754" class="form-control">
		</div>
		
		<label class="user">Email</label><br>
			<div class="input-group">
			<input type="email" name="email" placeholder="e.g example@gmail.com" class="form-control">
		</div>
		<label class="user">Password</label><br>
			<div class="input-group">
			<input type="password" name="password" placeholder="" class="form-control">
		</div><br>

<div class="input-group">
			<input type="submit" name="done" placeholder="" class="form-control">
		</div>
	</div>

</form>

</div>

<div class="col-md-4">
	<h3 class="text-success">Account Status</h3>
	<p class="text-white">
<?php

$conn=mysqli_connect("localhost","root","","ebanking");
?>


<?php


if(isset($_POST['done'])){
	$ID=$_POST['accountid'];
	$email=$_POST['email'];
	$password=$_POST['password'];
$q="select * from customer where cust_id='$ID' ";
$result=mysqli_query($conn,$q);
$data=mysqli_fetch_array($result);
echo "<h5 >You Current Status is </h5>";
echo "CusID = ".$data['cust_id'];
echo "<br>";
echo "Name = ".$data['cust_name'];
echo "<br>";
echo "Email = ".$data['cust_email'];
echo "<br>";
echo "Amount = ".$data['amount'];
}
?>

	</p>
</div>
</div>
</div>



<!--Bills -->
<div id="bills"  class="bg-dark text-white border border-primary my-3">
	<h1>PayBills</h1>

<div class="container-fluid padding" >
		<div class="row padding">
	<div class="6 col-lg-6">
		<p >A blog (a truncation of the expression "weblog")[1] is a discussion or informational website published on the World Wide Web consisting of discrete, often informal diary-style text entries (posts). Posts are typically displayed in reverse chronological order, so that the most recent post appears first, at the top of the web page. Until 2009, blogs were usually the work of a single individual,[citation needed] occasionally of a small group, and often covered a single subject or topic. In the 2010s, "multi-author blogs" (MABs) emerged, featuring the writing of multiple authors and sometimes professionally edited. MABs from newspapers, other media outlets, universities, think tanks, advocacy groups, and similar institutions account for an increasing quantity of blog traffic. The rise of Twitter and other "microblogging" systems helps integrate MABs and single-author blogs into the news media. Blog can also be used as a verb, meaning to maintain or add content to a blog.
</p>
<a href="#" class="btn btn-outline-primary" data-target="#mymodal" data-toggle="modal">Pay Bills</a>
<div class="modal " id="mymodal" >
	<div class="modal-dialog">
		<div class=" modal-content bg-dark">
			<div class="modal-header"></div>
			<button type="button" data-dismiss="modal" class="close">&times;</button>
		
<div class="modal-body">
	<form>
		<div class="form-group">
			<label>Bill ID</label>
		<div class="input-group">
			<input type="text" name="bill_id" class="form-control" placeholder="bill id">
		</div>
			<label>ACCCOUNT ID</label>
		<div class="input-group">
			<input type="text" name="acc_id" class="form-control" placeholder="account id">
		</div>
	</div>
	</form>
</div>
<div class="modal-footer">
	<button class="btn btn-success" data-dismiss="modal">Pay</button>
		<button class="btn btn-success" data-dismiss="modal">close</button>

</div>

	</div>
</div>
</div>

	</div>
<div class=" col-lg-6">
	<img src="img/bill.jpg" class="img-fluid py-0">
</div>
</div>
</div>




</div>
<!-- Car-->
<div id="car"  class="bg-dark text-white border border-primary my-3">
	<h1>Buy Car</h1>
	<div class="container-fluid padding" >
		<div class="row padding">
	<div class="6 col-lg-6">
		<p >A blog (a truncation of the expression "weblog")[1] is a discussion or informational website published on the World Wide Web consisting of discrete, often informal diary-style text entries (posts). Posts are typically displayed in reverse chronological order, so that the most recent post appears first, at the top of the web page. Until 2009, blogs were usually the work of a single individual,[citation needed] occasionally of a small group, and often covered a single subject or topic. In the 2010s, "multi-author blogs" (MABs) emerged, featuring the writing of multiple authors and sometimes professionally edited. MABs from newspapers, other media outlets, universities, think tanks, advocacy groups, and similar institutions account for an increasing quantity of blog traffic. The rise of Twitter and other "microblogging" systems helps integrate MABs and single-author blogs into the news media. Blog can also be used as a verb, meaning to maintain or add content to a blog.
</p>
<a href="#" class="btn btn-outline-primary" data-target="#mymodal2" data-toggle="modal">BUY CAR</a>
<div class="modal " id="mymodal2" >
	<div class="modal-dialog">
		<div class=" modal-content bg-dark">
			<div class="modal-header"></div>
			<button type="button" data-dismiss="modal" class="close">&times;</button>
		
<div class="modal-body">
	<form method="post" action="carbackend.php">
		<div class="form-group">
			<label>CAR ID</label>
		<div class="input-group">
			<input type="text" name="bill_id" class="form-control" placeholder="car id">
		</div>
			<label>ACCCOUNT ID</label>
		<div class="input-group">
			<input type="text" name="acc_id" class="form-control" placeholder="account id">
		</div>
	</div>
	</form>
</div>
<div class="modal-footer">
	<button class="btn btn-success" data-dismiss="modal" name="cardone">Pay INSTALLMENT</button>
		<button class="btn btn-success" data-dismiss="modal">close</button>

</div>

	</div>
</div>
</div>
	</div>
<div class=" col-lg-6">
	<img src="img/car.jpg" class="img-fluid py-0">
</div>
</div>
</div>

</div>



<!-- Home-->
<div id="car"  class="bg-dark text-white border border-primary my-3">
	<h1>Buy Home</h1>
	<div class="container-fluid padding" >
		<div class="row padding">
	<div class="6 col-lg-6">
		<p >A blog (a truncation of the expression "weblog")[1] is a discussion or informational website published on the World Wide Web consisting of discrete, often informal diary-style text entries (posts). Posts are typically displayed in reverse chronological order, so that the most recent post appears first, at the top of the web page. Until 2009, blogs were usually the work of a single individual,[citation needed] occasionally of a small group, and often covered a single subject or topic. In the 2010s, "multi-author blogs" (MABs) emerged, featuring the writing of multiple authors and sometimes professionally edited. MABs from newspapers, other media outlets, universities, think tanks, advocacy groups, and similar institutions account for an increasing quantity of blog traffic. The rise of Twitter and other "microblogging" systems helps integrate MABs and single-author blogs into the news media. Blog can also be used as a verb, meaning to maintain or add content to a blog.
</p>
<a href="#" class="btn btn-outline-primary" data-target="#mymodal3" data-toggle="modal">BUY HOME</a>
<div class="modal " id="mymodal3" >
	<div class="modal-dialog">
		<div class=" modal-content bg-dark">
			<div class="modal-header"></div>
			<button type="button" data-dismiss="modal" class="close">&times;</button>
		
<div class="modal-body">
	<form>
		<div class="form-group">
			<label>HOME ID</label>
		<div class="input-group">
			<input type="text" name="bill_id" class="form-control" placeholder="home id">
		</div>
			<label>ACCCOUNT ID</label>
		<div class="input-group">
			<input type="text" name="acc_id" class="form-control" placeholder="account id">
		</div>
	</div>
	</form>
</div>
<div class="modal-footer">
	<button class="btn btn-success" data-dismiss="modal">PAY INSTALLMENT</button>
		<button class="btn btn-success" data-dismiss="modal">close</button>

</div>

	</div>
</div>
</div>

	</div>
<div class=" col-lg-6">
	<img src="img/home.jpg" class="img-fluid py-0">
</div>
</div>
</div>

</div>






<div id="bills"  class="bg-dark text-white border border-primary my-3">
	<h1>Donate</h1>
	<div class="container-fluid padding" >
		<div class="row padding">
	<div class="6 col-lg-6">
		<p >A blog (a truncation of the expression "weblog")[1] is a discussion or informational website published on the World Wide Web consisting of discrete, often informal diary-style text entries (posts). Posts are typically displayed in reverse chronological order, so that the most recent post appears first, at the top of the web page. Until 2009, blogs were usually the work of a single individual,[citation needed] occasionally of a small group, and often covered a single subject or topic. In the 2010s, "multi-author blogs" (MABs) emerged, featuring the writing of multiple authors and sometimes professionally edited. MABs from newspapers, other media outlets, universities, think tanks, advocacy groups, and similar institutions account for an increasing quantity of blog traffic. The rise of Twitter and other "microblogging" systems helps integrate MABs and single-author blogs into the news media. Blog can also be used as a verb, meaning to maintain or add content to a blog.
</p>
<a href="#" class="btn btn-outline-primary" data-target="#mymodal4" data-toggle="modal">DONATE</a>
<div class="modal " id="mymodal4" >
	<div class="modal-dialog">
		<div class=" modal-content bg-dark">
			<div class="modal-header"></div>
			<button type="button" data-dismiss="modal" class="close">&times;</button>
		
<div class="modal-body">
	<form>
		<div class="form-group">
			<label>ORGANIZATION ID</label>
		<div class="input-group">
			<input type="text" name="bill_id" class="form-control" placeholder="organization id">
		</div>
			<label>ACCCOUNT ID</label>
		<div class="input-group">
			<input type="text" name="acc_id" class="form-control" placeholder="account id">
		</div>
			<label>AMOUNT</label>
		<div class="input-group">
			<input type="text" name="acc_id" class="form-control" placeholder="amount">
		</div>
	</div>
	</form>
</div>
<div class="modal-footer">
	<button class="btn btn-success" data-dismiss="modal">Pay INSTALLMENT</button>
		<button class="btn btn-success" data-dismiss="modal">close</button>

</div>

	</div>
</div>
</div>
	</div>
<div class=" col-lg-6">
	<img src="img/donate.jpg" class="img-fluid py-0">
</div>
</div>
</div>
</div>


<div id="bills"  class="bg-dark text-white border border-primary my-3">
	<h1>Meet Our Team</h1>
<div class="container-fluid padding">
	<div class="row padding">
		<div class="col-md-3">
		<div class="card">
		<img class="card-img-top" src="img/team1.jpg">
		<div class="card-body">
			<h4 class="card-tittle text-dark">John Doe</h4>
			<p class="card-text text-dark">
				John is Marketing EXpert for 20 years and is permanent team member
			</p>
			<a href="#" class="btn btn-outline-secondary">See Profile</a>
		</div>
		</div>
	</div>


<div class="col-md-3">
		<div class="card">
		<img class="card-img-top" src="img/team2.jpg">
		<div class="card-body">
			<h4 class="card-tittle text-dark">Mitchal</h4>
			<p class="card-text text-dark">
				John is Marketing EXpert for 20 years and is permanent team member
			</p>
			<a href="#" class="btn btn-outline-secondary">See Profile</a>
		</div>
		</div>
	</div>




<div class="col-md-3">
		<div class="card">
		<img class="card-img-top" src="img/team3.jpeg">
		<div class="card-body">
			<h4 class="card-tittle text-dark">Edward</h4>
			<p class="card-text text-dark">
				John is Marketing EXpert for 20 years and is permanent team member
			</p>
			<a href="#" class="btn btn-outline-secondary">See Profile</a>
		</div>
		</div>
	</div>





<div class="col-md-3">
		<div class="card">
		<img class="card-img-top" src="img/team2.jpg">
		<div class="card-body">
			<h4 class="card-tittle text-dark">Jack</h4>
			<p class="card-text text-dark">
				John is Marketing EXpert for 20 years and is permanent team member
			</p>
			<a href="#" class="btn btn-outline-secondary">See Profile</a>
		</div>
		</div>
	</div>




	</div>
</div>
</div>


<!--  signup      -->



<div class="container">
	<br/><br/>

<div class="row">
	
    <div class=" modal col-md-3 col-md-offset-5" id="signup">
<button id="closebar" type="button" class="close" data-dismiss="modal" >&times;</button>

     <form  method="post" action="register.php">
	 <div class="form-group">

     

     <b id="login-name" class="text-center">Signup</b>
<br/><br/>

     <label class="user">Username</label>
     <div class="input-group">
     <span class="input-group-addon"  id="iconn"> 
	 <i class="glyphicon glyphicon-user"></i></span>
     <input type="text" required="required"  class="form-control" id="username" name="username" placeholder="Enterusername">		
     </div>


      <label class="user">Email</label>
      <div class="input-group">
	  <span class="input-group-addon"  id="iconn"> 
	  <i class="glyphicon glyphicon-envelope"></i></span>
      <input type="email" required="required" class="form-control" id="email" name="email" placeholder="email">
      </div>


<label class="user">Password</label>
	  <div class="input-group">
	  <span class="input-group-addon"  id="iconn"> 
	  <i class="glyphicon glyphicon-lock"></i></span>
	  <input type="password"   required="required" class="form-control pwd" id="password" name="password"  placeholder="password"> 
	 
	  </div>




<label class="user">Password</label>
	  <div class="input-group">
	  <span class="input-group-addon"  id="iconn"> 
	  <i class="glyphicon glyphicon-lock"></i></span>
      <input type="Password"  id="pass" class="form-control pwd2" required="required" name="password2"  placeholder="confirmpassword"> 
	  				
      </div>



		<div class="input-group my-4">
        <br/>
		<input type="submit"  class="form-control bg-success text-white" onclick="addRecord()" name="register_btn" value="submit">
	    </div>
</div>
</form>
</div>
</div>
</center>









<!--END -->









<!-- Login -->

<div class="container">
	<br><br><br/><br/>

<div class="row">
    <div class="  modal col-md-3 mr-auto " id="login">
    	<button id="closebar" type="button" class="close " data-dismiss="modal" >&times;</button>

       <form  method="post"   action="login2.php">
	       <div class="form-group">

                      <b id="login-name">Login</b>
<br/><br/>

              
<label class="user">Email</label>
		<div class="input-group">
			<span class="input-group-addon"  id="iconn"> 
				<i class="glyphicon glyphicon-envelope"></i></span>

				<input type="email"  class="form-control" name="email"  id="email" required="required" placeholder="email">
				
		
		</div>


<label class="user">Password</label>
		<div class="input-group">
			<span class="input-group-addon"  id="iconn"> 
				<i class="glyphicon glyphicon-lock"></i></span>

				<input type="Password"  id="pass"  required="required" class="form-control pwd"  id="password" name="password"  placeholder="password"> 
			
		</div>


		<div class="input-group my-4">
<br/>
				<input  type="submit"  class="form-control bg-success text-white"  id="login2" name="register_btn" value="Login">
		

        </div>

</div>
</form>
</div>
</div>
</center>






<!-- End -->
<!--script for login-->



</div>
</body>
</html>