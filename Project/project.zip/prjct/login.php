<?php
//index.php
session_start();
if(isset($_SESSION["username"]))
{
 header("location:home.php");
}
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>

<style type="text/css">
	


#body{
/*background-image:linear-gradient(rgba(0,0,0,0.7),rgba(0,0,0,0.7)), url("BL12_Banking.jpg");  */
background-color:#111118 ; 
height:100vh;
	background-position: center;
	background-size: cover;
	background-repeat: no-repeat;
}

#login-name{
	font-size: 30px;
font-style: italic;
	color: white;
	font-weight: lighter;
}

#login{

	background-color: #0d0d0d;
	min-height: 400px;
	opacity: 0.70;
	padding: 30px 50px 30px 50px;
	box-shadow: -3px -3px 3px #33cc33;
}

.user{
font-style: italic;
	font-size: 14px;
	color: white;
	font-weight: lighter;

}

#iconn{
background-color: #5cb85c;
border-color:#4cae4c;
color: white;

}


.close {
  position: absolute;
  right: 25px;
  top: 0;
  color:white;
  font-size: 35px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color:white;
  cursor: pointer;
}

#closebar{

	color:white;
	opacity: 1;
}
</style>






<!-- Bootstrap -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">



<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	



</head>
<body id="body">



<div class="container">
	<br><br><br/><br/>

<div class="row">
    <div class=" col-md-6 mx-auto " id="login">
       <form  method="post" action="login2.php" >
	       <div class="form-group">

                      <b id="login-name">Login</b>
<br/><br/>

              
<label class="user">Email</label>
		<div class="input-group">
			<span class="input-group-addon"  id="iconn"> 
				<i class="glyphicon glyphicon-envelope"></i></span>

				<input type="email"  class="form-control" name="email"  id="email"  required="required" placeholder="email">
				
		
		</div>


<label class="user">Password</label>
		<div class="input-group">
			<span class="input-group-addon"  id="iconn"> 
				<i class="glyphicon glyphicon-lock"></i></span>

				<input type="Password"  id="pass"  required="required" class="form-control pwd" id="password" name="password"  placeholder="password"> 
				 <span class="input-group-btn">
            <button class="btn btn-success reveal" type="button"><i class="glyphicon glyphicon-eye-open"></i></button>
          </span> 
		</div>

		<div class="input-group">
<br/>
				<input  type="submit"  class="form-control" name="register_btn" value="Login" id="login2">
		

        </div>


		

</div>
</form>
</div>
</div>
</center>





<script>
$(".reveal").on('click',function() {
    var $pwd = $(".pwd");
    if ($pwd.attr('type') === 'password') {
        $pwd.attr('type', 'text');
    } else {
        $pwd.attr('type', 'password');
    }
});


$(".reveal2").on('click',function() {
    var $pwd2 = $(".pwd2");
    if ($pwd2.attr('type') === 'password') {
        $pwd2.attr('type', 'text');
    } else {
        $pwd2.attr('type', 'password');
    }
});


// auto popup signup box



</script>
</body>
</html>





<script>
$(document).ready(function(){
 $('#login2').click(function(){
  var email = $('#email').val();
  var password = $('#password').val();
  if($.trim(email).length > 0 && $.trim(password).length > 0)
  {
   $.ajax({
    url:"login2.php",
    method:"POST",
    data:{email:email, password:password},
    cache:false,
    beforeSend:function(){
     $('#login2').val("connecting...");
    },
    success:function(data)
    {
     if(data)
     {
      $("body").load("home.php").hide().fadeIn(1500);
     }
     else
     {
      var options = {
       distance: '40',
       direction:'left',
       times:'3'
      }
      $("#box").effect("shake", options, 800);
      $('#login2').val("Login");
      $('#error').html("<span class='text-danger'>Invalid username or Password</span>");
     }
    }
   });
  }
  else
  {

  }
 });
});
</script>