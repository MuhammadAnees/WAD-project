<?php
session_start();
?>
<?php

$con=mysqli_connect("localhost","root","","authentication");

if(isset($_POST['register_btn'])){
$email=$_POST['email'];
$password=$_POST['password'];

	$query="select * from users where email= '$email' AND password='$password'";
	$result=mysqli_query($conn,$query);
	$data=mysqli_fetch_array($result))

	if($data){
$_SESSION['uname'] = $data['username'];	
	header("location:home.php");
	}
	else{
		echo "not a valid user";
		header("location:register.php");
	}


}



?>




<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h1>Welcome bruh! you are logged in successfully</h1>
</body>
</html>